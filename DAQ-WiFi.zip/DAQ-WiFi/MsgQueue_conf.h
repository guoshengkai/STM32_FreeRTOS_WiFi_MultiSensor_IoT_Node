//-------- <<< Use Configuration Wizard in Context Menu >>> --------------------
//     <o>Memory pool buffers
//     <i>Number of memory pool buffers
#define MSGQUEUE_OBJECTS 26                     // number of Message Queue Objects

//------------- <<< end of configuration section >>> ---------------------------
