


//-------- <<< Use Configuration Wizard in Context Menu >>> --------------------
// <h>ADC configuration 
// =======================

//     <o>Sample Rate
//     <i>Define the sample rate in milli seconds
#define SAMPLE_RATE_MS	1

//     <o>Sample buffer Size
//     <i>Define sample buffer size in int16
#define CHANNEL_SAMPLE_SIZE 250   

//     <o>Number of ADC Channels
//     <i>Define number of active ADC channels
#define NUM_CHANNELS 8

// </h>
//------------- <<< end of configuration section >>> ---------------------------

#define TIMER3_RELOAD_VALUE 199 *  SAMPLE_RATE_MS

#define TOTAL_SAMPLE_SIZE (CHANNEL_SAMPLE_SIZE * NUM_CHANNELS)
#define HALF_SAMPLE_SIZE (TOTAL_SAMPLE_SIZE / 2)
#define TOTAL_SAMPLE_SIZE_BYTES  (TOTAL_SAMPLE_SIZE * 2)
#define HALF_SAMPLE_SIZE_BYTES  (HALF_SAMPLE_SIZE * 2)

#define LOWER_BUFFER 1
#define UPPER_BUFFER 2