extern ADC_HandleTypeDef hadc1;
extern DMA_HandleTypeDef hdma_adc1;
extern ADC_HandleTypeDef hadc3;	
extern TIM_HandleTypeDef htim3;

extern uint16_t Adc1Buf[];

extern 	void ADC_Calibrate (void);
extern 	void ADC_Start (void);
//extern 	void process_lower_buffer (void);
extern 	void processBuffer (uint32_t bufferSelect);
extern void ADC_Stop (void);

typedef struct {
	char msgT[15];
	uint16_t Adc1Buf[1000];
	uint16_t adc3Value;
	uint16_t EoF; //0xAA55
}__DAQ_DATA ;


