/*********************************************************************************
**                                                                          		**
** Copyright (C) Hitex (UK) Ltd. 2025							                    					**
**                                                                          		**
** All rights reserved.                                                     		**
**                                                                          		**
** This document contains proprietary information belonging to Hitex        		**
** Development Tools GmbH. Passing on and copying of this document, and     		**
** communication of its contents is not permitted without prior written     		**
** authorization.                                                           		**
**********************************************************************************
**                                                                          		**
** FILENAME : Command_Thread.c                                           				**
**                                                                          		**
** VERSION : 1.0.0	                                                        		**
**                                                                          		**
** DATE : 2025.05.28		                                                      	**
**                                                                          		**
** VARIANT : mainline                                              							**
**                                                                          		**
** PLATFORM : STM STM32L4					                                    					**
**                                                                          		**
** AUTHOR : Trevor Martin                                                    		**
**                                                                         			**
** VENDOR : Hitex (UK) Ltd.					                               				     	**
**                                                                          		**
** DESCRIPTION : RTX Command Thread 									                  				**
**                                                                          		**
** SPECIFICATION(S) : <spec name, version>                                  		**
**                                                                          		**
** MAY BE CHANGED BY USER : yes 		                                   	    		**
**                                                                          		**
*********************************************************************************/

#include <stdbool.h>
#include <stdio.h>


#include "main.h"
#include "RTE_Components.h"

#if defined(RTE_CMSIS_View_EventRecorder)
#include "EventRecorder.h"
#endif

#include "rtos.h"                         
#include "mqtt.h"
#include "wifi.h"
#include "adc.h"
#include "File_System.h"

#include "command.h"


struct __config daqConfig = { .logging = false, \
													 .wifi = false, 
													 .MQTT = false,\
													 .filesystem = false,\
													 "lu/DAQ1/status",\
													 "lu/DAQ1/data",\
													 "lu/DAQ1/control/#"};

osThreadId_t tid_Command_Thread;  		
													 
/************************************************************************//**
 *
 * \function       void Command_Thread (void *argument)
 *										
 *
 * \description   RTX Thread that is used to process commands from the Host controller
 ****************************************************************************
 * \param[in]     void *argument  not used
 * \param[out]    None 
 *
 * \param[in,out] None	
 *
 * \return        None 	
 *
 ****************************************************************************/
													 
 void Command_Thread (void *argument) {
uint32_t command;
	
  while (1) {
    command = osThreadFlagsWait(0x0F,osFlagsWaitAny,osWaitForever);

		switch(command)
		{
			case  CMD_LOG_DATA_ON :
						#if defined(RTE_CMSIS_View_EventRecorder)
								EventRecord2(0x4 + EventLevelAPI,NULL,NULL);
						#endif
						daqConfig.logging = true;
						ADC_Calibrate ();
						ADC_Start ();		
			break;
			
			case CMD_LOG_DATA_OFF :
						ADC_Stop();
						daqConfig.logging = false;
			break;
			
			case CMD_SAVE_TO_FILE :
						if(isFileSystemEnabled() == false)
							fileSystem_start ();
			break;
			
			case CMD_CLOSE_FILE :
						if(isFileSystemEnabled() == true)
							daqConfig.filesystem = false;
			break;
						
			case CMD_DELETE_FILE :
						fileSystem_delete_file ( "DAQ.dat");
			break;
			
			case CMD_MQTT_DISCONNECT :
						ADC_Stop();
						daqConfig.logging = false;
						daqConfig.MQTT = false;
						mqtt_disconnect ();
						daqConfig.wifi = false;
						socket_close();
			break;
			
			default :
						printf("Unknown Command \n");
			break;
						
		}
  }
}
 
/************************************************************************//**
 *
 * \function    int Init_Command_Thread (void)  
 *										
 *
 * \description   Calling this function launches the command thread
 ****************************************************************************
 * \param[in]     None
 * \param[out]    None 
 *
 * \param[in,out] None	
 *
 * \return        None 	
 *
 ****************************************************************************/

int Init_Command_Thread (void) {
 
  tid_Command_Thread = osThreadNew(Command_Thread, NULL, NULL);
  if (tid_Command_Thread == NULL) {
    return(-1);
  }
 
  return(0);
}
