#include "main.h"
#include "ADC.h"

ADC_HandleTypeDef hadc1;
DMA_HandleTypeDef hdma_adc1;
ADC_HandleTypeDef hadc3;	
TIM_HandleTypeDef htim3;

	
uint16_t Adc1Buf[CHANNEL_SIZE1*BUF_MAX_SIZE1];	


	void ADC_Calibrate (void)
	{
		HAL_ADCEx_Calibration_Start(&hadc1,ADC_SINGLE_ENDED);
  }
	
	
	void ADC_Start (void)
	{
		HAL_ADC_Start_DMA(&hadc1,(uint32_t *)Adc1Buf,CHANNEL_SIZE1*BUF_MAX_SIZE1);
		HAL_ADC_Start_IT(&hadc3);
		HAL_TIM_Base_Start(&htim3);
	}