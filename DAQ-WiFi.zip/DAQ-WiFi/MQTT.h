
extern void mqtt_connect (void);
extern void mqtt_publish_time (char* payload,uint32_t size);
extern void mqtt_publish_time_upper (char* payload,uint32_t size);
extern void mqtt_publish (char topic[20],char* payload,uint32_t size);
extern void mqtt_subscribe_control (char *topic);
extern void mqtt_publish_signon (char * payload,uint32_t size);
extern void mqtt_publish_signoff (char * payload,uint32_t size);
extern void mqtt_disconnect (void);
extern void mqtt_yield (void);
extern int8_t isLoggingEnabled(void);
extern int8_t isMqttConnected (void);