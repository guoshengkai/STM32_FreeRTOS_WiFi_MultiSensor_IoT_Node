/*********************************************************************************
**                                                                          		**
** Copyright (C) Hitex (UK) Ltd. 2025							                    					**
**                                                                          		**
** All rights reserved.                                                     		**
**                                                                          		**
** This document contains proprietary information belonging to Hitex        		**
** Development Tools GmbH. Passing on and copying of this document, and     		**
** communication of its contents is not permitted without prior written     		**
** authorization.                                                           		**
**********************************************************************************
**                                                                          		**
** FILENAME : File_System.c      		                                     				**
**                                                                          		**
** VERSION : 1.0.0	                                                        		**
**                                                                          		**
** DATE : 2025.05.28		                                                      	**
**                                                                          		**
** VARIANT : mainline                                              							**
**                                                                          		**
** PLATFORM : STM STM32L4					                                    					**
**                                                                          		**
** AUTHOR : Trevor Martin                                                    		**
**                                                                         			**
** VENDOR : Hitex (UK) Ltd.					                               				     	**
**                                                                          		**
** DESCRIPTION :  File system management and access functions            				**
**                                                                          		**
** SPECIFICATION(S) : <spec name, version>                                  		**
**                                                                          		**
** MAY BE CHANGED BY USER : yes 		                                   	    		**
**                                                                          		**
*********************************************************************************/

#include <string.h>
#include <stdio.h>
#include "rl_fs.h"

#include "main.h"
#include "RTE_Components.h"

#if defined(RTE_CMSIS_View_EventRecorder)
#include "EventRecorder.h"
#endif

#include "RTOS.h"
#include "command.h"
#include "adc.h"

#include "fileSystem.h"

/************************************************************************//**
 *
 * \function     int32_t fs_mc_read_cd	(	uint32_t 	drive_num	) 
 *										
 *
 * \description   Overload function for the card detect pin. Always returns true
 ****************************************************************************
 * \param[in]     None
 * \param[out]    None 
 *
 * \param[in,out] None	
 *
 * \return        None 	
 *
 ****************************************************************************/
 
int32_t fs_mc_read_cd	(	uint32_t 	drive_num	)
{
	return 1;
}

/************************************************************************//**
 *
 * \function      int32_t fs_mc_spi_control_ss	(	uint32_t 	drive_num,uint32_t 	ss )
 *										
 *
 * \description   SD card slave select control function
 ****************************************************************************
 * \param[in]     None
 * \param[out]    None 
 *
 * \param[in,out] None	
 *
 * \return        None 	
 *
 ****************************************************************************/

int32_t fs_mc_spi_control_ss	(	uint32_t 	drive_num,uint32_t 	ss )
{
	if(ss == 0)
	{
		HAL_GPIO_WritePin(GPIOD, 5,GPIO_PIN_SET);
	}
	else
	{
		HAL_GPIO_WritePin(GPIOD, 5,GPIO_PIN_RESET);
	}
return ss;
}	

/************************************************************************//**
 *
 * \function      int8_t isFileSystemEnabled (void)
 *										
 *
 * \description   Helper function. returns files system registration state
 ****************************************************************************
 * \param[in]     None
 * \param[out]    None 
 *
 * \param[in,out] None	
 *
 * \return        None 	
 *
 ****************************************************************************/

int8_t isFileSystemEnabled (void)
{
	return daqConfig.filesystem; 
}

/************************************************************************//**
 *
 * \function      void fileSystem_start (void)
 *										
 *
 * \description   Initialises and mounts the SD card
 ****************************************************************************
 * \param[in]     None
 * \param[out]    None 
 *
 * \param[in,out] None	
 *
 * \return        None 	
 *
 ****************************************************************************/

void fileSystem_start (void)
{
	fsStatus stat;
	
	if (finit ("M0:") != fsOK)
		printf("File system failed to initialise\n");
	
	stat = fmount ("M0:");
	if (stat != fsOK) 
		printf("filesystem failed to mount\n");
	else	
		daqConfig.filesystem = true;
}

/************************************************************************//**
 *
 * \function     void fileSystem_close (void) 
 *										
 *
 * \description   Unmounts and uninitialises the SD card file system
 ****************************************************************************
 * \param[in]     None
 * \param[out]    None 
 *
 * \param[in,out] None	
 *
 * \return        None 	
 *
 ****************************************************************************/

void fileSystem_close (void)
{
	funmount("M0:");
	funinit("M0:");
	daqConfig.filesystem = false;
	printf("File system unmounted\n");
}

/************************************************************************//**
 *
 * \function      void fileSystem_delete_file ( char *filename)
 *										
 *
 * \description   Delete the DAQ.dat data file
 ****************************************************************************
 * \param[in]     char *filename
 * \param[out]    None 
 *
 * \param[in,out] None	
 *
 * \return        None 	
 *
 ****************************************************************************/

void fileSystem_delete_file ( char *filename)
{
	if (fdelete ("DAQ.dat", NULL) == fsOK) {                   // Delete a file from current drive.
    printf ("Deleted: %s\n",filename);
  }
}

/************************************************************************//**
 *
 * \function     void fileSystem_Save_ADC_Data_To_SD(struct __DAQ_DATA *data,int size) 
 *										
 *
 * \description   Saves the logged data structure to the SD card
 ****************************************************************************
 * \param[in]     struct __DAQ_DATA *data,int size
 * \param[out]    None 
 *
 * \param[in,out] None	
 *
 * \return        None 	
 *
 ****************************************************************************/

void fileSystem_Save_ADC_Data_To_SD(struct __DAQ_DATA *data,int size) {
FILE *fout;
	
fout = fopen("DAQ.dat","a");
	if(fout != NULL)
	{
		fwrite (data, sizeof (char), size, fout); 
		fclose(fout);
	}			
}
		
	