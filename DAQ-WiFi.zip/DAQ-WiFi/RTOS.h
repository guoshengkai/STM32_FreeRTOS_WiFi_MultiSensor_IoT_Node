#include "cmsis_os2.h"

extern osThreadId_t app_main_handle;