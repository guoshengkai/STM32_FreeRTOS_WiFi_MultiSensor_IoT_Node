 #define  CMD_LOG_DATA_ON	'1'
 #define  CMD_LOG_DATA_OFF '2'
 #define  CMD_SAVE_TO_FILE '3'
 #define  CMD_CLOSE_FILE '4'
 #define CMD_DELETE_FILE '5'
 #define  CMD_MQTT_DISCONNECT '6'

struct __config
{
		char logging;
		char wifi;
		char MQTT;
		char filesystem;
	  char statusTopic[15];
		char dataTopic[15];
		char commandTopic[20];
};

extern struct __config daqConfig;

extern osThreadId_t tid_Command_Thread;  

extern int Init_Command_Thread (void);