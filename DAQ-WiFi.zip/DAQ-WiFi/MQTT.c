/*********************************************************************************
**                                                                          		**
** Copyright (C) Hitex (UK) Ltd. 2025							                    					**
**                                                                          		**
** All rights reserved.                                                     		**
**                                                                          		**
** This document contains proprietary information belonging to Hitex        		**
** Development Tools GmbH. Passing on and copying of this document, and     		**
** communication of its contents is not permitted without prior written     		**
** authorization.                                                           		**
**********************************************************************************
**                                                                          		**
** FILENAME : MQTT.c                                    					       				**
**                                                                          		**
** VERSION : 1.0.0	                                                        		**
**                                                                          		**
** DATE : 2025.05.28		                                                      	**
**                                                                          		**
** VARIANT : mainline                                              							**
**                                                                          		**
** PLATFORM : STM STM32L4					                                    					**
**                                                                          		**
** AUTHOR : Trevor Martin                                                    		**
**                                                                         			**
** VENDOR : Hitex (UK) Ltd.					                               				     	**
**                                                                          		**
** DESCRIPTION :  MQTT Management functions						                  				**
**                                                                          		**
** SPECIFICATION(S) : <spec name, version>                                  		**
**                                                                          		**
** MAY BE CHANGED BY USER : yes 		                                   	    		**
**                                                                          		**
*********************************************************************************/

#include <stdbool.h>
#include <stdio.h>
#include <string.h>

#include "RTE_Components.h"

#if defined(RTE_CMSIS_View_EventRecorder)
#include "EventRecorder.h"
#endif
#include "debug.h"

#include "ADC_Conf.h"
#include "MQTTClient.h"
#include "command.h"

#include "MQTT.h"
#include "MQTT_Conf.h"

MQTTClient client;
Network network;
 
char state = 0;
unsigned char sendbuf[(HALF_SAMPLE_SIZE_BYTES + 600)], readbuf[80];

/************************************************************************//**
 *
 * \function     int8_t isLoggingEnabled(void) 
 *										
 *
 * \description  Helper function returns logging state 
 ****************************************************************************
 * \param[in]     None
 * \param[out]    None 
 *
 * \param[in,out] None	
 *
 * \return        True or False	
 *
 ****************************************************************************/
 
int8_t isLoggingEnabled(void)
{
	return daqConfig.logging;	
}	

/************************************************************************//**
 *
 * \function     int8_t isMqttConnected (void) 
 *										
 *
 * \description  Helper function returns MQTT connection state
 ****************************************************************************
 * \param[in]     None
 * \param[out]    None 
 *
 * \param[in,out] None	
 *
 * \return        True or False	
 *
 ****************************************************************************/

int8_t isMqttConnected (void)
{
	return daqConfig.MQTT; 
}

/************************************************************************//**
 *
 * \function      void messageArrived(MessageData* data)
 *										
 *
 * \description   Callback function for received message topics. Triggers the Command thread
 ****************************************************************************
 * \param[in]     MessageData* data  received message buffer
 * \param[out]    None 
 *
 * \param[in,out] None	
 *
 * \return        None 	
 *
 ****************************************************************************/

void messageArrived(MessageData* data)
{
//#if defined (DEBUG_INFO)
//  printf("Message arrived on topic %.*s: %.*s\n", data->topicName->lenstring.len, data->topicName->lenstring.data,
//					data->message->payloadlen, (char *)data->message->payload);
//#endif

	state = *(char *)data->message->payload;							// Extract the command index

#if defined(RTE_CMSIS_View_EventRecorder)
	EventRecord2(0x2 + EventLevelAPI,state,NULL);					//sendbuf command index to the debugger
#endif

	osThreadFlagsSet(tid_Command_Thread, state);					// set the command value as a pattern of flags to signal the command thread
}

/************************************************************************//**
 *
 * \function      void mqtt_publish (char topic[20],char* payload,uint32_t size)
 *										
 *
 * \description   MQTT message publish function
 ****************************************************************************
 * \param[in]     None
 * \param[out]    char topic[20],char* payload,uint32_t sizee 
 *
 * \param[in,out] None	
 *
 * \return        None 	
 *
 ****************************************************************************/

void mqtt_publish (char topic[20],char* payload,uint32_t size)
{
int rc = 0, count = 0;
	
	MQTTMessage message;
	message.qos = QOS1;
  message.retained = 0;
  message.payload = payload;
  message.payloadlen = size;

  if ((rc = MQTTPublish(&client,topic , &message)) != 0)							//Publish an MQTT topic and data
     printf("Return code from MQTT publish is %d\n", rc);

}

/************************************************************************//**
 *
 * \function      void mqtt_publish_signon (char * payload,uint32_t size)
 *										
 *
 * \description   Publishes the sign off message. Must be called before disconnecting from the MQTT server
 ****************************************************************************
 * \param[in]     char * payload,uint32_t size
 * \param[out]    None 
 *
 * \param[in,out] None	
 *
 * \return        None 	
 *
 ****************************************************************************/

void mqtt_publish_signon (char * payload,uint32_t size)
{
int rc = 0, count = 0;
	
	MQTTMessage message;
	message.qos = QOS0;
  message.retained = 0;
  message.payload = payload;
  message.payloadlen = size;
	
  if ((rc = MQTTPublish(&client, daqConfig.statusTopic, &message)) != 0)
     printf("Return code from MQTT publish is %d\n", rc);
#if defined(RTE_CMSIS_View_EventRecorder)
	else
		EventRecord2(0x3 + EventLevelAPI,NULL,NULL);
#endif
}

/************************************************************************//**
 *
 * \function      void mqtt_publish_signoff (char * payload,uint32_t size)
 *										
 *
 * \description   Publishes the sign off message. Must be called before disconnecting from the MQTT server
 ****************************************************************************
 * \param[in]     char * payload,uint32_t size
 * \param[out]    None 
 *
 * \param[in,out] None	
 *
 * \return        None 	
 *
 ****************************************************************************/

void mqtt_publish_signoff (char * payload,uint32_t size)
{
int rc = 0, count = 0;

	MQTTMessage message;
	message.qos = QOS1;
  message.retained = 0;
  message.payload = payload;
  message.payloadlen = size;
	

  if ((rc = MQTTPublish(&client,daqConfig.statusTopic, &message)) != 0)
     printf("Return code from MQTT publish is %d\n", rc);
#if defined(RTE_CMSIS_View_EventRecorder)	
	else
 	EventRecord2(0xE,NULL,NULL);
#endif
}

/************************************************************************//**
 *
 * \function      void mqtt_subscribe_control (char topic[])
 *										
 *
 * \description   Sunscribes to a provided MQTT topic
 ****************************************************************************
 * \param[in]     char topic[]  the topic string 
 * \param[out]    None 
 *
 * \param[in,out] None	
 *
 * \return        None 	
 *
 ****************************************************************************/

void mqtt_subscribe_control (char topic[])
{
uint32_t rc;	
	
  if ((rc = MQTTSubscribe(&client, topic, QOS0, messageArrived)) != 0)
    printf("Return code from MQTT subscribe is %d\n", rc);
#if defined(RTE_CMSIS_View_EventRecorder)
	else 
			EventRecord2(0x6 + EventLevelAPI,NULL,NULL);
#endif
}

/************************************************************************//**
 *
 * \function      void mqtt_yield (void)
 *										
 *
 * \description   Runs the MQTT stack. Must be called at periodic intervals
 ****************************************************************************
 * \param[in]     None
 * \param[out]    None 
 *
 * \param[in,out] None	
 *
 * \return        None 	
 *
 ****************************************************************************/

void mqtt_yield (void)
{
	 MQTTYield(&client, 5);
}

/************************************************************************//**
 *
 * \function      void mqtt_connect (void)
 *										
 *
 * \description   Connects and registers the MQTT server specified in MQTT_Conf.h
 ****************************************************************************
 * \param[in]     None
 * \param[out]    None 
 *
 * \param[in,out] None	
 *
 * \return        None 	
 *
 ****************************************************************************/

void mqtt_connect (void)
{
int rc = 0, count = 0;
MQTTPacket_connectData connectData = MQTTPacket_connectData_initializer;
	
	NetworkInit(&network);
	MQTTClientInit(&client, &network, 30000, sendbuf, sizeof(sendbuf), readbuf, sizeof(readbuf));
	if ((rc = NetworkConnect(&network, SERVER_NAME, SERVER_PORT)) != 0)
			printf("Return code from network connect is %d\n", rc);
	
	connectData.will.topicName.cstring = "lu/DAQ1/status";
	connectData.will.message.cstring = "{\"status\":\"offline\"}";
	connectData.willFlag = 1;
	connectData.MQTTVersion = 3;
  connectData.clientID.cstring = "DAQ1";
	 
#if MQTT_AUTHENTICATION_REQUIRED == 1									//set user and password for authenticated broker. Configured in MQTT_Conf.h
	connectData.username.cstring = SERVER_USER;
	connectData.password.cstring = SERVER_PASS;
#endif
 
	if ((rc = MQTTConnect(&client, &connectData)) == 0)
	{
		daqConfig.MQTT = true;
#if defined(RTE_CMSIS_View_EventRecorder) 
		EventRecord2(0x1 + EventLevelAPI,NULL,NULL);
	}
	else
	{
		EventRecord2(0xD + EventLevelAPI,rc,NULL);
#endif
	}
}

/************************************************************************//**
 *
 * \function      void mqtt_disconnect (void)
 *										
 *
 * \description   Disconnects and deregisters the MQTT server
 ****************************************************************************
 * \param[in]     None
 * \param[out]    None 
 *
 * \param[in,out] None	
 *
 * \return        None 	
 *
 ****************************************************************************/

void mqtt_disconnect (void)
{	
	mqtt_publish_signoff ("{\"status\":\"offline\"}",20);
	daqConfig.MQTT = false;
	NetworkDisconnect(&network);
#if defined(RTE_CMSIS_View_EventRecorder) 
		EventRecord2(0xC + EventLevelAPI,NULL,NULL);
#endif
}