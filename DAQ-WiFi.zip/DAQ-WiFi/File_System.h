

extern void fileSystem_start (void);
extern int8_t isFileSystemEnabled (void);
extern void fileSystem_delete_file ( char *filename);
//extern void fileSystem_Save_ADC_Data_To_SD(uint16_t *adcBuffer, uint16_t size, RTC_TimeTypeDef *sTime, RTC_DateTypeDef *sDate, uint16_t adc3Value);