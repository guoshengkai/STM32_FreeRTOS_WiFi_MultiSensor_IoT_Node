./objects/ssl_tls13_client.o: \
  C:\Users\Trevor\AppData\Local\Arm\Packs\ARM\mbedTLS\3.6.0\library\ssl_tls13_client.c \
  RTE\_B-L475E-IOT01A\Pre_Include_Global.h \
  C:\Users\Trevor\AppData\Local\Arm\Packs\ARM\mbedTLS\3.6.0\library\common.h \
  C:\Users\Trevor\AppData\Local\Arm\Packs\ARM\mbedTLS\3.6.0\include\mbedtls\build_info.h \
  C:\Users\Trevor\AppData\Local\Arm\Packs\ARM\mbedTLS\3.6.0\RTE\include\mbedTLS_config_wrapper.h \
  RTE\Security\mbedTLS_config.h \
  C:\Users\Trevor\AppData\Local\Arm\Packs\ARM\mbedTLS\3.6.0\include\mbedtls\config_adjust_legacy_crypto.h \
  C:\Users\Trevor\AppData\Local\Arm\Packs\ARM\mbedTLS\3.6.0\include\mbedtls\config_adjust_x509.h \
  C:\Users\Trevor\AppData\Local\Arm\Packs\ARM\mbedTLS\3.6.0\include\mbedtls\config_adjust_ssl.h \
  C:\Users\Trevor\AppData\Local\Arm\Packs\ARM\mbedTLS\3.6.0\include\mbedtls\check_config.h \
  C:\Users\Trevor\AppData\Local\Arm\Packs\ARM\mbedTLS\3.6.0\library\alignment.h
