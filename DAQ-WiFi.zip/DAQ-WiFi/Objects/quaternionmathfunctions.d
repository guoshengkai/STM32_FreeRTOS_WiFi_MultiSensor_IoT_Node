./objects/quaternionmathfunctions.o: \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\QuaternionMathFunctions\QuaternionMathFunctions.c \
  RTE\_B-L475E-IOT01A\Pre_Include_Global.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\QuaternionMathFunctions\arm_quaternion_norm_f32.c \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\dsp\quaternion_math_functions.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\arm_math_types.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS\6.1.0\CMSIS\Core\Include\cmsis_compiler.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS\6.1.0\CMSIS\Core\Include\cmsis_armclang.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\arm_math_memory.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\dsp\none.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\dsp\utils.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\QuaternionMathFunctions\arm_quaternion_inverse_f32.c \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\QuaternionMathFunctions\arm_quaternion_conjugate_f32.c \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\QuaternionMathFunctions\arm_quaternion_normalize_f32.c \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\QuaternionMathFunctions\arm_quaternion_product_single_f32.c \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\QuaternionMathFunctions\arm_quaternion_product_f32.c \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\QuaternionMathFunctions\arm_quaternion2rotation_f32.c \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\QuaternionMathFunctions\arm_rotation2quaternion_f32.c
