./objects/statisticsfunctionsf16.o: \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\StatisticsFunctions\StatisticsFunctionsF16.c \
  RTE\_B-L475E-IOT01A\Pre_Include_Global.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\StatisticsFunctions\arm_max_f16.c \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\dsp\statistics_functions_f16.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\arm_math_types_f16.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\arm_math_types.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS\6.1.0\CMSIS\Core\Include\cmsis_compiler.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS\6.1.0\CMSIS\Core\Include\cmsis_armclang.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\arm_math_memory.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\dsp\none.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\dsp\utils.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\dsp\basic_math_functions_f16.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\dsp\fast_math_functions_f16.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\dsp\fast_math_functions.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\dsp\basic_math_functions.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\StatisticsFunctions\arm_min_f16.c \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\StatisticsFunctions\arm_mean_f16.c \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\StatisticsFunctions\arm_power_f16.c \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\StatisticsFunctions\arm_rms_f16.c \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\StatisticsFunctions\arm_std_f16.c \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\StatisticsFunctions\arm_var_f16.c \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\StatisticsFunctions\arm_entropy_f16.c \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\StatisticsFunctions\arm_kullback_leibler_f16.c \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\StatisticsFunctions\arm_logsumexp_dot_prod_f16.c \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\StatisticsFunctions\arm_logsumexp_f16.c \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\StatisticsFunctions\arm_max_no_idx_f16.c \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\StatisticsFunctions\arm_min_no_idx_f16.c \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\StatisticsFunctions\arm_absmax_f16.c \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\StatisticsFunctions\arm_absmin_f16.c \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\StatisticsFunctions\arm_absmax_no_idx_f16.c \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\StatisticsFunctions\arm_absmin_no_idx_f16.c \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\StatisticsFunctions\arm_mse_f16.c \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\StatisticsFunctions\arm_accumulate_f16.c
