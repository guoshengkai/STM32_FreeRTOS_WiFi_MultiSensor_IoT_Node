./objects/retarget_io.o: \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-Compiler\2.1.0\source\armcc\retarget_io.c \
  RTE\_B-L475E-IOT01A\Pre_Include_Global.h \
  RTE\_B-L475E-IOT01A\RTE_Components.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-Compiler\2.1.0\include\retarget_fs.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-Compiler\2.1.0\include\retarget_stderr.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-Compiler\2.1.0\include\retarget_stdin.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-Compiler\2.1.0\include\retarget_stdout.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-Compiler\2.1.0\include\retarget_tty.h
