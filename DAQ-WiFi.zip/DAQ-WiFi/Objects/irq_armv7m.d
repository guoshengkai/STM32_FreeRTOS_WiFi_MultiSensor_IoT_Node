./objects/irq_armv7m.o: \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-RTX\5.9.0\Source\GCC\irq_armv7m.S \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-RTX\5.9.0\Include\rtx_def.h \
  RTE\_B-L475E-IOT01A\RTE_Components.h RTE\CMSIS\RTX_Config.h
