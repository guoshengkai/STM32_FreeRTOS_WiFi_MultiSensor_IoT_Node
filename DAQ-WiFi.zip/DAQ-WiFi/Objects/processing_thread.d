./objects/processing_thread.o: Processing_Thread.c \
  RTE\_B-L475E-IOT01A\Pre_Include_Global.h \
  RTE\Device\STM32L475VGTx\STCubeGenerated\Inc\main.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal.h \
  RTE\Device\STM32L475VGTx\STCubeGenerated\Inc\stm32l4xx_hal_conf.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_rcc.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_def.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\CMSIS\Device\ST\STM32L4xx\Include\stm32l4xx.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\CMSIS\Device\ST\STM32L4xx\Include\stm32l475xx.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS\6.1.0\CMSIS\Core\Include\core_cm4.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\CMSIS\Device\ST\STM32L4xx\Include\system_stm32l4xx.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\Legacy\stm32_hal_legacy.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_rcc_ex.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_gpio.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_gpio_ex.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_dma.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_cortex.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_adc.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_ll_adc.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_adc_ex.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_exti.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_flash.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_flash_ex.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_flash_ramfunc.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_pwr.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_pwr_ex.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_rng.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_rtc.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_rtc_ex.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_spi.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_spi_ex.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_tim.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_tim_ex.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_uart.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_uart_ex.h \
  RTE\_B-L475E-IOT01A\RTE_Components.h FileSystem\Include\rl_fs.h RTOS.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS\6.1.0\CMSIS\RTOS2\Include\cmsis_os2.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-View\1.2.0\EventRecorder\Include\EventRecorder.h \
  MQTT.h ADC.h WiFi.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS\6.1.0\CMSIS\Driver\Include\Driver_WiFi.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS\6.1.0\CMSIS\Driver\Include\Driver_Common.h \
  WiFi_ISM43362.h command.h
