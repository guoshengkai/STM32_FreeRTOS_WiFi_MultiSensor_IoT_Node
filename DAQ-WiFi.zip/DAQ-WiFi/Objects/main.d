./objects/main.o: RTE\Device\STM32L475VGTx\STCubeGenerated\Src\main.c \
  RTE\_B-L475E-IOT01A\Pre_Include_Global.h \
  RTE\Device\STM32L475VGTx\STCubeGenerated\Inc\main.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal.h \
  RTE\Device\STM32L475VGTx\STCubeGenerated\Inc\stm32l4xx_hal_conf.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_rcc.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_def.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\CMSIS\Device\ST\STM32L4xx\Include\stm32l4xx.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\CMSIS\Device\ST\STM32L4xx\Include\stm32l475xx.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS\6.1.0\CMSIS\Core\Include\core_cm4.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\CMSIS\Device\ST\STM32L4xx\Include\system_stm32l4xx.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\Legacy\stm32_hal_legacy.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_rcc_ex.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_gpio.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_gpio_ex.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_dma.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_cortex.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_adc.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_ll_adc.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_adc_ex.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_exti.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_flash.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_flash_ex.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_flash_ramfunc.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_pwr.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_pwr_ex.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_rng.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_rtc.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_rtc_ex.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_spi.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_spi_ex.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_tim.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_tim_ex.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_uart.h \
  D:\Program\ Files(Keil\ pack)\Keil\STM32L4xx_DFP\2.6.0\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_uart_ex.h \
  ..\DAQ-WiFi\RTOS.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS\6.1.0\CMSIS\RTOS2\Include\cmsis_os2.h \
  RTE\_B-L475E-IOT01A\RTE_Components.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-View\1.2.0\EventRecorder\Include\EventRecorder.h \
  ..\DAQ-WiFi\File_System.h ..\DAQ-WiFi\ADC.h ..\DAQ-WiFi\ADC_Conf.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\arm_math.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\arm_math_types.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS\6.1.0\CMSIS\Core\Include\cmsis_compiler.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\arm_math_memory.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\dsp\none.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\dsp\utils.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\dsp\basic_math_functions.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\dsp\interpolation_functions.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\dsp\bayes_functions.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\dsp\statistics_functions.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\dsp\fast_math_functions.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\dsp\matrix_functions.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\dsp\complex_math_functions.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\dsp\controller_functions.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\dsp\support_functions.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\dsp\distance_functions.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\dsp\svm_functions.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\dsp\svm_defines.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\dsp\transform_functions.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\dsp\filtering_functions.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\dsp\quaternion_math_functions.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\dsp\window_functions.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\arm_const_structs.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\arm_common_tables.h
