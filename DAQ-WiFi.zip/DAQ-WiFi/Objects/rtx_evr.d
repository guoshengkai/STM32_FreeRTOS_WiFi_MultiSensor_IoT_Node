./objects/rtx_evr.o: \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-RTX\5.9.0\Source\rtx_evr.c \
  RTE\_B-L475E-IOT01A\Pre_Include_Global.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS\6.1.0\CMSIS\Core\Include\cmsis_compiler.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS\6.1.0\CMSIS\Core\Include\cmsis_armclang.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-RTX\5.9.0\Include\rtx_evr.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-RTX\5.9.0\Include\rtx_os.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS\6.1.0\CMSIS\RTOS2\Include\cmsis_os2.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-RTX\5.9.0\Include\rtx_def.h \
  RTE\_B-L475E-IOT01A\RTE_Components.h RTE\CMSIS\RTX_Config.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-View\1.2.0\EventRecorder\Include\EventRecorder.h \
  RTE\CMSIS-View\EventRecorderConf.h
