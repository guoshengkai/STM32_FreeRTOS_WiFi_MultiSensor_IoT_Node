./objects/basicmathfunctionsf16.o: \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\BasicMathFunctions\BasicMathFunctionsF16.c \
  RTE\_B-L475E-IOT01A\Pre_Include_Global.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\BasicMathFunctions\arm_abs_f16.c \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\dsp\basic_math_functions_f16.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\arm_math_types_f16.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\arm_math_types.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS\6.1.0\CMSIS\Core\Include\cmsis_compiler.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS\6.1.0\CMSIS\Core\Include\cmsis_armclang.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\arm_math_memory.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\dsp\none.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Include\dsp\utils.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\BasicMathFunctions\arm_add_f16.c \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\BasicMathFunctions\arm_dot_prod_f16.c \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\BasicMathFunctions\arm_mult_f16.c \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\BasicMathFunctions\arm_negate_f16.c \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\BasicMathFunctions\arm_offset_f16.c \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\BasicMathFunctions\arm_scale_f16.c \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\BasicMathFunctions\arm_sub_f16.c \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS-DSP\1.16.2\Source\BasicMathFunctions\arm_clip_f16.c
