./objects/iot_socket.o: \
  D:\Program\ Files(Keil\ pack)\MDK-Packs\IoT_Socket\1.4.0\source\wifi\iot_socket.c \
  RTE\_B-L475E-IOT01A\Pre_Include_Global.h \
  D:\Program\ Files(Keil\ pack)\MDK-Packs\IoT_Socket\1.4.0\include\iot_socket.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS\6.1.0\CMSIS\Driver\Include\Driver_WiFi.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS\6.1.0\CMSIS\Driver\Include\Driver_Common.h
