./objects/mqttplatform.o: \
  D:\Program\ Files(Keil\ pack)\MDK-Packs\Paho_MQTT\1.0.4\MQTTClient-C\src\mdk\MQTTPlatform.c \
  RTE\_B-L475E-IOT01A\Pre_Include_Global.h \
  D:\Program\ Files(Keil\ pack)\MDK-Packs\Paho_MQTT\1.0.4\MQTTClient-C\src\mdk\MQTTPlatform.h \
  D:\Program\ Files(Keil\ pack)\ARM\CMSIS\6.1.0\CMSIS\RTOS2\Include\cmsis_os2.h \
  D:\Program\ Files(Keil\ pack)\MDK-Packs\IoT_Socket\1.4.0\include\iot_socket.h \
  RTE\_B-L475E-IOT01A\RTE_Components.h
