/*********************************************************************************
**                                                                          		**
** Copyright (C) Hitex (UK) Ltd. 2025							                    					**
**                                                                          		**
** All rights reserved.                                                     		**
**                                                                          		**
** This document contains proprietary information belonging to Hitex        		**
** Development Tools GmbH. Passing on and copying of this document, and     		**
** communication of its contents is not permitted without prior written     		**
** authorization.                                                           		**
**********************************************************************************
**                                                                          		**
** FILENAME : MQTT_Conf.h			                                           				**
**                                                                          		**
** VERSION : 1.0.0	                                                        		**
**                                                                          		**
** DATE : 2025.05.28		                                                      	**
**                                                                          		**
** VARIANT : mainline                                              							**
**                                                                          		**
** PLATFORM : STM STM32L4					                                    					**
**                                                                          		**
** AUTHOR : Trevor Martin                                                    		**
**                                                                         			**
** VENDOR : Hitex (UK) Ltd.					                               				     	**
**                                                                          		**
** DESCRIPTION :  MQTT configuration options					                  				**
**                                                                          		**
** SPECIFICATION(S) : <spec name, version>                                  		**
**                                                                          		**
** MAY BE CHANGED BY USER : yes 		                                   	    		**
**                                                                          		**
*********************************************************************************/


//-------- <<< Use Configuration Wizard in Context Menu >>> --------------------

// <h>MQTT Server 
// =======================
//     <s>Server Name
//     <i>Define the name of the MQTT Server 
//		 <i>This may be an IP address or URL
//#define SERVER_NAME "broker.hivemq.com"
#define SERVER_NAME "10.0.0.112"          //  10.0.0.133

//     <o>Server Port
//     <i>Define unencrypted port normally 1883
#define SERVER_PORT 1883
// </h>

// <e> Enable Broker logon authentication
#define MQTT_AUTHENTICATION_REQUIRED	1

#if  MQTT_AUTHENTICATION_REQUIRED == 1
//     <s>User Name
//     <i>Define the MQTT user name
#define SERVER_USER "lu"

//     <s>User Password
//     <i>Define the user password
#define SERVER_PASS "password"
#endif
// </e>

//------------- <<< end of configuration section >>> ---------------------------

