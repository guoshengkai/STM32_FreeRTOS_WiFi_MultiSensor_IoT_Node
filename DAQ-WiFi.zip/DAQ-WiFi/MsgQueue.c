/*********************************************************************************
**                                                                          		**
** Copyright (C) Hitex (UK) Ltd. 2025							                    					**
**                                                                          		**
** All rights reserved.                                                     		**
**                                                                          		**
** This document contains proprietary information belonging to Hitex        		**
** Development Tools GmbH. Passing on and copying of this document, and     		**
** communication of its contents is not permitted without prior written     		**
** authorization.                                                           		**
**********************************************************************************
**                                                                          		**
** FILENAME : MsgQueue.c                                    					       		**
**                                                                          		**
** VERSION : 1.0.0	                                                        		**
**                                                                          		**
** DATE : 2025.07.17		                                                      	**
**                                                                          		**
** VARIANT : mainline                                              							**
**                                                                          		**
** PLATFORM : STM STM32L4					                                    					**
**                                                                          		**
** AUTHOR : Trevor Martin                                                    		**
**                                                                         			**
** VENDOR : Hitex (UK) Ltd.					                               				     	**
**                                                                          		**
** DESCRIPTION :  Creates Message Queue and memory pool and sends ADC data      **
**								from DMA callback to the processing thread             				**
**                                                                          		**
** SPECIFICATION(S) : <spec name, version>                                  		**
**                                                                          		**
** MAY BE CHANGED BY USER : yes 		                                   	    		**
**                                                                          		**
*********************************************************************************/

#include <stdio.h>
#include <string.h>

#include "cmsis_os2.h"  
#include "RTE_Components.h"
#if defined(RTE_CMSIS_View_EventRecorder)
#include "EventRecorder.h"
#endif

#include "main.h"
#include "adc.h"
#include "RTC.h"
#include "adc_Conf.h"

#include "MsgQueue_conf.h"
#include "MsgQueue.h"

osMessageQueueId_t mid_MsgQueue;                
osMemoryPoolId_t mpool;

#if defined(RTE_CMSIS_View_EventRecorder)
	uint32_t adcTxCounter = 0;										//debug counter used to monitor ADC buffer transfer count
#endif

/************************************************************************//**
 *
 * \function    	int Init_MsgQueue (void)
 *										
 *
 * \description   This function initialises a message queue and memory pool
 *								this is used to send ADC data to the processing thread.
 ****************************************************************************
 * \param[in]     ADC_HandleTypeDef* hadc ADC instance
 * \param[out]    Sets the LOWER_BUFFER thread flag on the processing thread
 *
 * \param[in,out] None	
 *
 * \return        int 	
 *
 ****************************************************************************/
 
int Init_MsgQueue (void) {
int status = 0;
	
	mpool = osMemoryPoolNew(MSGQUEUE_OBJECTS, sizeof(__DAQ_DATA),NULL );						// create a pool of memory buffers to hold the ADC data
	if (mpool == NULL) {
   status = MESSAGE_QUEUE_ERROR;
  }
	
  mid_MsgQueue = osMessageQueueNew(MSGQUEUE_OBJECTS, 4, NULL);										// Create a message queue to buffer list of active memory pool buffers
  if (mid_MsgQueue == NULL) {
  status = MEMORY_POOL_ERROR;
  }
	
  return(status);
}

/************************************************************************//**
 *
 * \function      void HAL_ADC_ConvHalfCpltCallback(ADC_HandleTypeDef* hadc)
 *										
 *
 * \description   Callback function for the DMA complete interrupt. The callback
 *								copies the Upper half of the DMA buffer to a Memory pool block 
 *								and posts a pointer to the block into the message queue
 ****************************************************************************
 * \param[in]     ADC_HandleTypeDef* hadc ADC instance
 * \param[out]    Sets the LOWER_BUFFER thread flag on the processing thread
 *
 * \param[in,out] None	
 *
 * \return        None 	
 *
 ****************************************************************************/

 void HAL_ADC_ConvHalfCpltCallback(ADC_HandleTypeDef* hadc)
{
__DAQ_DATA *msg;	
osStatus_t status;	

	msg = (__DAQ_DATA*)osMemoryPoolAlloc(mpool,0U);								//Allocate a memory block from the pool. Important timeout must be zero
	
#if defined(RTE_CMSIS_View_EventRecorder)
	uint32_t blockCount = osMemoryPoolGetCount(mpool);						//Get count of memory buffers in use
	
	adcTxCounter++;																								//DebugMonitor_IRQn TX counter
	msg->adc3Value = adcTxCounter;																// This is checked on receive to ensure no missing blocks
	EventRecord2(0x7,adcTxCounter,blockCount);
#endif
	
	HAL_RTC_GetTime(&hrtc, &sTime, RTC_FORMAT_BIN);								// Read ADC, format and write into the memory pool block
  HAL_RTC_GetDate(&hrtc, &sDate, RTC_FORMAT_BIN);
	uint32_t ms = 1000 - ((sTime.SubSeconds * 1000) / sTime.SecondFraction);
	if (ms == 1000) ms = 999; // Ensures ms is always 0-999													
	sprintf(msg->msgT, "T:%02d:%02d:%02d.%03lu\r\n",sTime.Hours, sTime.Minutes, sTime.Seconds, ms); 

	memcpy(msg->Adc1Buf,Adc1Buf,HALF_SAMPLE_SIZE_BYTES);					//copy the ADC data into the memory pool block

	status = osMessageQueuePut(mid_MsgQueue, &msg, 0U, 0U);				//post the memory pool pointer into the message queue
#if defined(RTE_CMSIS_View_EventRecorder)
	if(status != osOK)
	{
		 EventRecord2(0x10,status,NULL);
	}
#endif
}

/************************************************************************//**
 *
 * \function      void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc)
 *										
 *
 * \description   Callback function for the DMA complete interrupt. The callback
 *								copies the Upper half of the DMA buffer to a Memory pool block 
 *								and posts a pointer to the block into the message queue
 ****************************************************************************
 * \param[in]    ADC_HandleTypeDef* hadc ADC instance
 * \param[out]   
 *
 * \param[in,out] None	
 *
 * \return        None 	
 *
 ****************************************************************************/

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc)
{
__DAQ_DATA *msg;
osStatus_t status;
	
	msg = (__DAQ_DATA*)osMemoryPoolAlloc(mpool,0U);					//Allocate a memory block from the pool. Important timeout must be zero
	
#if defined(RTE_CMSIS_View_EventRecorder)	
	uint32_t blockCount = osMemoryPoolGetCount(mpool);			//Get count of memory buffers in use
	adcTxCounter++;																					//DebugMonitor_IRQn TX counter
	msg->adc3Value = adcTxCounter;													// This is checked in process thread on receive to ensure no missing blocks
  EventRecord2(0x8,adcTxCounter,blockCount);
#endif
	
	HAL_RTC_GetTime(&hrtc, &sTime, RTC_FORMAT_BIN);					// Read ADC, format and write into the memory pool block
  HAL_RTC_GetDate(&hrtc, &sDate, RTC_FORMAT_BIN);
	uint32_t ms = 1000 - ((sTime.SubSeconds * 1000) / sTime.SecondFraction);
	if (ms == 1000) ms = 999; // Ensures ms is always 0-999													
	sprintf(msg->msgT, "T:%02d:%02d:%02d.%03lu\r\n",sTime.Hours, sTime.Minutes, sTime.Seconds, ms); 

	memcpy(msg->Adc1Buf,&Adc1Buf[HALF_SAMPLE_SIZE],HALF_SAMPLE_SIZE_BYTES);	//copy the ADC data into the memory pool block
	
	status = 	osMessageQueuePut(mid_MsgQueue, &msg, 0U, 0U);	//post the memory pool pointer into the message queue
#if defined(RTE_CMSIS_View_EventRecorder)
	if(status != osOK)
	{
		 EventRecord2(0x10,status,NULL);
	}
#endif
}


