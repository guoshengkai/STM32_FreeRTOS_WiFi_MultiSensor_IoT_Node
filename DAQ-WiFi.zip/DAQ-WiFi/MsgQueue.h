

extern osMessageQueueId_t mid_MsgQueue; 
extern osMemoryPoolId_t mpool;

#define MESSAGE_QUEUE_ERROR 0x01
#define MEMORY_POOL_ERROR 0x01