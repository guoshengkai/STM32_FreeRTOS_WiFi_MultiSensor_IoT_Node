


extern void WiFi_ISM43362_Pin_DATARDY_IRQ (void);