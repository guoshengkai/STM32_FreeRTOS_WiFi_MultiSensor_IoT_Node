/*********************************************************************************
**                                                                          		**
** Copyright (C) Hitex (UK) Ltd. 2025							                    					**
**                                                                          		**
** All rights reserved.                                                     		**
**                                                                          		**
** This document contains proprietary information belonging to Hitex        		**
** Development Tools GmbH. Passing on and copying of this document, and     		**
** communication of its contents is not permitted without prior written     		**
** authorization.                                                           		**
**********************************************************************************
**                                                                          		**
** FILENAME : ADC_Processing.c                                           				**
**                                                                          		**
** VERSION : 1.0.0	                                                        		**
**                                                                          		**
** DATE : 2025.05.28		                                                      	**
**                                                                          		**
** VARIANT : mainline                                              							**
**                                                                          		**
** PLATFORM : STM STM32L4					                                    					**
**                                                                          		**
** AUTHOR : Trevor Martin                                                    		**
**                                                                         			**
** VENDOR : Hitex (UK) Ltd.					                               				     	**
**                                                                          		**
** DESCRIPTION : ADC management and data processing		                  				**
**                                                                          		**
** SPECIFICATION(S) : <spec name, version>                                  		**
**                                                                          		**
** MAY BE CHANGED BY USER : yes 		                                   	    		**
**                                                                          		**
*********************************************************************************/




#include <stdio.h>
#include <string.h>

#include "rl_fs.h"

#include "RTE_Components.h"
#include "main.h"

#if defined(RTE_CMSIS_View_EventRecorder)
#include "EventRecorder.h"
#endif

#include "RTOS.h"
#include "File_System.h"
#include "MQTT.h"

#include "WiFi.h"
#include "command.h"
#include "MsgQueue.h"
#include "adc_Conf.h"
#include "ADC.h"


uint32_t adcRxCounter = 0;
uint16_t Adc1Buf[TOTAL_SAMPLE_SIZE];	

/************************************************************************//**
 *
 * \function      void ADC_Calibrate (void)
 *										
 *
 * \description   Calibrate the ADC for single ended conversions
 ****************************************************************************
 * \param[in]     None
 * \param[out]    None 
 *
 * \param[in,out] None	
 *
 * \return        None 	
 *
 ****************************************************************************/
 
void ADC_Calibrate (void)
{
	HAL_ADCEx_Calibration_Start(&hadc1,ADC_SINGLE_ENDED);
}

/************************************************************************//**
 *
 * \function      void ADC_clearEOC (ADC_HandleTypeDef *hadc)
 *										
 *
 * \description   Clear the ADC End of Conversion flag. This starts the next conversion
 ****************************************************************************
 * \param[in]     ADC_HandleTypeDef *hadc the ADC instance
 * \param[out]    None 
 *
 * \param[in,out] None	
 *
 * \return        None 	
 *
 ****************************************************************************/

void ADC_clearEOC (ADC_HandleTypeDef *hadc)
{
	 hadc3.Instance->ISR = hadc3.Instance->ISR & ~ ADC_FLAG_EOC;	
}

/************************************************************************//**
 *
 * \function      void ADC_Stop (void)
 *										
 *
 * \description   Halts the ADC and timer and resets the buffer flags
 ****************************************************************************
 * \param[in]     None
 * \param[out]    None 
 *
 * \param[in,out] None	
 *
 * \return        None 	
 *
 ****************************************************************************/

void ADC_Stop (void)
{
	HAL_TIM_Base_Stop(&htim3);
	HAL_ADC_Stop_DMA(&hadc1);	
}

/************************************************************************//**
 *
 * \function      void ADC_Start (void)
 *										
 *
 * \description   Starts the ADC conversion including trigger timer and DMA
 ****************************************************************************
 * \param[in]     None
 * \param[out]    None 
 *
 * \param[in,out] None	
 *
 * \return        None 	
 *
 ****************************************************************************/

void ADC_Start (void)
{
	HAL_ADC_Stop_DMA(&hadc1);
	HAL_ADC_Start_DMA(&hadc1,(uint32_t *)Adc1Buf,TOTAL_SAMPLE_SIZE);
	HAL_TIM_Base_Start(&htim3);		
	HAL_ADC_Start(&hadc3);
}		

/************************************************************************//**
 *
 * \function     void processBuffer (uint32_t bufferSelect) 
 *										
 *
 * \description  Processes the ADC data buffer when a DMA interrupt occurs, 
 *							 publishes the MQTT message and logs data to the SD card 
 ****************************************************************************
 * \param[in]    int32_t bufferSelect Buffer half to process
 * \param[out]    None 
 *
 * \param[in,out] None	
 *
 * \return        None 	
 *
 ****************************************************************************/

void processBuffer (uint32_t bufferSelect)
{
FILE *fout;
ADC_HandleTypeDef *ADC_3;
osStatus_t status;
__DAQ_DATA *daqData;

	status = osMessageQueueGet(mid_MsgQueue, &daqData, NULL, osWaitForever);

#if defined(RTE_CMSIS_View_EventRecorder)
	if(status != osOK)
	{
		EventRecord2(0x11,NULL,NULL);	
	}
	adcRxCounter++;
	if (adcRxCounter != daqData->adc3Value)
	{
		EventRecord2(0x5 + EventLevelError,adcRxCounter,daqData->adc3Value);		
	 }
	else
	{
		EventRecord2(0x9 + EventLevelAPI, adcRxCounter,daqData->adc3Value);	
	}
#endif							
	ADC_clearEOC (&hadc3);
	
	daqData->adc3Value = HAL_ADC_GetValue(&hadc3);
	
	if(isFileSystemEnabled() == true)
	{
		fout = fopen("DAQ.dat","a");
		if(fout != NULL)
		{
#if defined(RTE_CMSIS_View_EventRecorder)
			EventRecord2(0x11 + EventLevelAPI,NULL,NULL);
#endif
			fwrite (daqData, sizeof (char), sizeof(daqData), fout); 
			fclose(fout);
		}
#if defined(RTE_CMSIS_View_EventRecorder)
		else
		{
			EventRecord2(0x10 + EventLevelError,NULL,NULL);
		}
#endif
  }
	
	if (isMqttConnected() == true)
	{
		
#if defined(RTE_CMSIS_View_EventRecorder)
		EventRecord2(0xA + EventLevelAPI,NULL,NULL);
#endif
		daqData->EoF = 0xAA55;
		mqtt_publish (daqConfig.dataTopic,daqData,(sizeof(__DAQ_DATA)));		
		osMemoryPoolFree(mpool,daqData);
		
#if defined(RTE_CMSIS_View_EventRecorder)
		uint32_t blockCount = osMemoryPoolGetCount(mpool);
		EventRecord2(0xB + EventLevelAPI,blockCount,NULL);
//		if(adcRxCounter == 500)
//		{
//			__BKPT();					Transfer test
//		}
#endif
	}
}







