


//-------- <<< Use Configuration Wizard in Context Menu >>> --------------------
// <h>WiFi Credentials
// =======================
//     <s>SSID Name
//     <i>Define the name of the network you wish to connect to
#define SSID           "Robot24"  // Robot24

//     <s>Password
//     <i>Enter the pass key for the network
#define PASSWORD       "test1234"  // test1234


#define SECURITY_TYPE   ARM_WIFI_SECURITY_WPA2

// </h>
//------------- <<< end of configuration section >>> ---------------------------

#define SECURITY_TYPE   ARM_WIFI_SECURITY_WPA2
