/*********************************************************************************
**                                                                          		**
** Copyright (C) Hitex (UK) Ltd. 2025							                    					**
**                                                                          		**
** All rights reserved.                                                     		**
**                                                                          		**
** This document contains proprietary information belonging to Hitex        		**
** Development Tools GmbH. Passing on and copying of this document, and     		**
** communication of its contents is not permitted without prior written     		**
** authorization.                                                           		**
**********************************************************************************
**                                                                          		**
** FILENAME : WiFi.c                                    					       				**
**                                                                          		**
** VERSION : 1.0.0	                                                        		**
**                                                                          		**
** DATE : 2025.05.28		                                                      	**
**                                                                          		**
** VARIANT : mainline                                              							**
**                                                                          		**
** PLATFORM : STM STM32L4					                                    					**
**                                                                          		**
** AUTHOR : Trevor Martin                                                    		**
**                                                                         			**
** VENDOR : Hitex (UK) Ltd.					                               				     	**
**                                                                          		**
** DESCRIPTION :  WiFi Management functions						                  				**
**                                                                          		**
** SPECIFICATION(S) : <spec name, version>                                  		**
**                                                                          		**
** MAY BE CHANGED BY USER : yes 		                                   	    		**
**                                                                          		**
*********************************************************************************/

#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>

#include "RTE_Components.h"
#include "main.h"

#if defined(RTE_CMSIS_View_EventRecorder)
#include "EventRecorder.h"
#endif

#include "RTOS.h"
#include "command.h"

#include "wifi.h"
#include "WiFi_Conf.h"

ARM_WIFI_NET_INFO_t netInfo;
uint8_t ip[4];          // IP address
uint8_t sn[4];          // IP address
uint8_t gw[4];

int8_t isWifiConnected (void)
{
	if (Driver_WiFi0.IsConnected() == 0U) 
      return (false);
		else
			return true;		
}

/************************************************************************//**
 *
 * \function      void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
 *										
 *
 * \description    EXTI line detection callback.
 ****************************************************************************
 * \param[in]     GPIO_Pin: Specifies the port pin connected to corresponding EXTI line. 
 * \param[out]    None 
 *
 * \param[in,out] None	
 *
 * \return        None 	
 *
 ****************************************************************************/

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
  if (GPIO_Pin == GPIO_PIN_1) {
    WiFi_ISM43362_Pin_DATARDY_IRQ();
  }
}

/************************************************************************//**
 *
 * \function      int32_t socket_startup (void)
 *										
 *
 * \description   Starts and registers the WiFi Module and connects to the server address specified in wifi_conf.h
 ****************************************************************************
 * \param[in]     None
 * \param[out]    None 
 *
 * \param[in,out] None	
 *
 * \return       -1 for failure 0 for connected	
 *
 ****************************************************************************/

int32_t socket_startup (void) {
  ARM_WIFI_CONFIG_t config;

  printf("Connecting to WiFi ...\r\n");

  Driver_WiFi0.Initialize  (NULL);
  Driver_WiFi0.PowerControl(ARM_POWER_FULL);
  
  memset((void *)&config, 0, sizeof(config));

  config.ssid     = SSID;
  config.pass     = PASSWORD;
  config.security = SECURITY_TYPE;
  config.ch       = 0U;

  Driver_WiFi0.Activate(0U, &config);
	

  if (Driver_WiFi0.IsConnected() == 0U) {
    
    return (-1);
  } else {
    daqConfig.wifi = true;
    Driver_WiFi0.GetNetInfo(&netInfo);
#if defined(RTE_CMSIS_View_EventRecorder)
		EventRecord2(0xF + EventLevelAPI,NULL,NULL);
#endif
    
  }
  return 0;
}

/************************************************************************//**
 *
 * \function      void socket_close(void)
 *										
 *
 * \description   Closes the WiFi socket and deregisters the driver
 ****************************************************************************
 * \param[in]     None
 * \param[out]    None 
 *
 * \param[in,out] None	
 *
 * \return        None 	
 *
 ****************************************************************************/

void socket_close(void)
{
	daqConfig.wifi = false;
	Driver_WiFi0.Deactivate(0);
}