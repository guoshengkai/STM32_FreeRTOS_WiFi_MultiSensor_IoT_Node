#include "Driver_WiFi.h"
#include "WiFi_ISM43362.h"

extern int32_t socket_startup (void);
extern void socket_close(void);
extern int8_t isWifiConnected (void);

extern ARM_DRIVER_WIFI Driver_WiFi0;