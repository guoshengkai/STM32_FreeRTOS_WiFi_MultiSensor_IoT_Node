

extern void fileSystem_start (void);
extern int8_t isFileSystemEnabled (void);
extern void fileSystem_delete_file ( char *filename);