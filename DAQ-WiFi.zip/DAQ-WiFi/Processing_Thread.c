/*********************************************************************************
**                                                                          		**
** Copyright (C) Hitex (UK) Ltd. 2025							                    					**
**                                                                          		**
** All rights reserved.                                                     		**
**                                                                          		**
** This document contains proprietary information belonging to Hitex        		**
** Development Tools GmbH. Passing on and copying of this document, and     		**
** communication of its contents is not permitted without prior written     		**
** authorization.                                                           		**
**********************************************************************************
**                                                                          		**
** FILENAME : Processing_Thread                                          				**
**                                                                          		**
** VERSION : 1.0.0	                                                        		**
**                                                                          		**
** DATE : 2025.05.28		                                                      	**
**                                                                          		**
** VARIANT : mainline                                              							**
**                                                                          		**
** PLATFORM : STM STM32L4					                                    					**
**                                                                          		**
** AUTHOR : Trevor Martin                                                    		**
**                                                                         			**
** VENDOR : Hitex (UK) Ltd.					                               				     	**
**                                                                          		**
** DESCRIPTION : RTX ADC Processing Thread						                  				**
**                                                                          		**
** SPECIFICATION(S) : <spec name, version>                                  		**
**                                                                          		**
** MAY BE CHANGED BY USER : yes 		                                   	    		**
**                                                                          		**
*********************************************************************************/

#include <stdio.h>

#include "main.h"
#include "RTE_Components.h"

#include "rl_fs.h"
#include "RTOS.h"

#if defined(RTE_CMSIS_View_EventRecorder)
#include "EventRecorder.h"
#endif

#include "MQTT.h"
#include "ADC.h"
#include "WiFi.h"
#include "command.h"

osThreadId_t app_main_handle;

static const osThreadAttr_t app_main_attr = {
  .stack_size = 10096U
};
extern int Init_MsgQueue (void);

/************************************************************************//**
 *
 * \function     static void processing (void *argument)
 *										
 *
 * \description   app_main is the thread used to log process store and transmit the ADC sensor data
 ****************************************************************************
 * \param[in]     void *argument  not used
 * \param[out]    None 
 *
 * \param[in,out] None	
 *
 * \return        None 	
 *
 ****************************************************************************/

static void processing (void *argument) {
  (void)argument;

uint32_t bufferSelect; 

	Init_Command_Thread();
	Init_MsgQueue ();																									
  if(socket_startup () == 0)																				//Connect to the WiFi Network
	{
		
#if defined(RTE_CMSIS_View_EventRecorder)
		EventRecorderInitialize (EventRecordAll, 1);
#endif
		
		mqtt_connect();																									//connect to MQTT Broker
		mqtt_subscribe_control (daqConfig.commandTopic);								// Subscribe to receive command topic
		mqtt_publish_signon("{\"status\":\"online\"}",19);																// Publish the signon message
	}
		daqConfig.logging = true;																					//Auto start logging during development
		ADC_Calibrate ();
		ADC_Start ();	
	for (;;) 
	{
		mqtt_yield ();																									// Run the MQTT stack
		
	  if( isLoggingEnabled() == 1)												
		{
			processBuffer (bufferSelect);																	// If logging enabled process and send the ADC data
		}
	}
}


/************************************************************************//**
 *
 * \function      void init_Processing_Thread (void)
 *										
 *
 * \description   this function is used to launch the app_main thread
 ****************************************************************************
 * \param[in]     None
 * \param[out]    None 
 *
 * \param[in,out] None	
 *
 * \return        None 	
 *
 ****************************************************************************/

void init_Processing_Thread (void) {
 app_main_handle = osThreadNew(processing, NULL, &app_main_attr);
}
